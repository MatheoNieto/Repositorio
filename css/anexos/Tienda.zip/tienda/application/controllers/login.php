<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {

    
    public function __construct(){
        parent::__construct();
        $this->load->model('login_model');
    }

    
    public function index(){ 
      if($this->session->userdata('tipou')){
        $session_id = $this->session->userdata('tipou');

            if ($session_id == 1){
                redirect('menu_principal'); 

            }else{
                redirect('cajero');
            }

        }else{
            $this->load->view('index');
        }       


    }
    
    public function ingresar(){
         $cedula = $this->input->post('cedula');
        $contrasena = $this->input->post('password');
            if ($this->login_model->login($cedula,$contrasena) == TRUE ){
                
                $prueba['tipo'] = $this->login_model->tipou($cedula,$contrasena);
                
                
                $variablesession = array(
                'codigo'=> $cedula,
                'tipou'=>$prueba['tipo'][0]['rol_id_rol']
                );

                if( $prueba['tipo'][0]['rol_id_rol'] == 1){
                    $this->session->set_userdata($variablesession);
                    redirect('menu_principal','refresh');
                    
                }else{
                    $this->session->set_userdata($variablesession);
                    redirect('cajero','refresh');                    
                }
        }else{                 
                echo 'false';             
            }
    }
  
    
    
    
    public function cerrarsession() {
        
        $this->session->sess_destroy();
        redirect('login');
    }
    
}
