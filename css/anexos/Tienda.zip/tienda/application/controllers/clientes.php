<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Clientes extends CI_Controller {

    
    public function __construct(){
        parent::__construct();
    	 $this->load->model('clientes_model');
    }

    
    public function index(){ 

         $sesion = $this->session->userdata('codigo'); 
          $sesion2 = $this->session->userdata('tipou'); 
        if($sesion){  
            
            if ($sesion2 == 1){
                   $this->load->view('clientes'); 
         $this->load->view('clientes3');             

            }else{
              redirect('cajero'); 
            }
    }else{
            redirect('login'); 
        }



    }

    public function registrarc(){
        
         $cedula = $this->input->post('cedula');
         $nombre = $this->input->post('nombre');
         $telefono = $this->input->post('telefono');
        
     $datos = array(
                'cedula_c' => $cedula,
                'nombre_c' => $nombre,
                'telefono_c' => $telefono
               
            );
        
        
        $this->clientes_model->regiscliente($datos);

    
    }

    public function clientesm(){

    	 $datosclientes['clientes'] = $this->clientes_model->clientesm();
    	 $this->load->view('clientes2',$datosclientes);

    }

    public function eliminarcli(){

 $cedula = $this->input->post('cedula');
 $this->clientes_model->eliminar($cedula);


    }

    public function modificar(){

    	  $cedula = $this->input->post('cedula');
         $nombre = $this->input->post('nombre');
         $telefono = $this->input->post('telefono');
        
     $datos = array(
                'cedula_c' => $cedula,
                'nombre_c' => $nombre,
                'telefono_c' => $telefono
               
            );

        $this->clientes_model->modificarcli($datos,$cedula);
    }


}