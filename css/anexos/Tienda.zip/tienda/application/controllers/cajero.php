<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cajero extends CI_Controller {

    
    public function __construct(){
        parent::__construct();
    $this->load->model('cajero_model');
    }

    
    public function index(){ 
      $sesion = $this->session->userdata('codigo'); 
          $sesion2 = $this->session->userdata('tipou'); 
        if($sesion){  
            
            if ($sesion2 == 1){
        $this->load->view('admin');       

            }else{
             $this->load->view('cajero');    
             $this->load->view('cajero2');    
             $this->load->view('cajero3');    
            }
    }else{
            redirect('login'); 
        } 
}
    
    
    public function consultar(){
        
         $cedula = $this->input->post('cedula');
        
        if ($this->cajero_model->cliente($cedula) == false ){
        
        echo 'false';        
        
    }else{
            $datosclientes['clientes'] = $this->cajero_model->cliente($cedula);
            
           $this->load->view('cajero2',$datosclientes);
            
        }
    
    }  public function registrarc(){
        
         $cedula = $this->input->post('cedula');
         $nombre = $this->input->post('nombre');
         $telefono = $this->input->post('telefono');
        
     $datos = array(
                'cedula_c' => $cedula,
                'nombre_c' => $nombre,
                'telefono_c' => $telefono
               
            );
        
        
        $this->cajero_model->regiscliente($datos);

    
    }
    
    
    
    
    
    
}