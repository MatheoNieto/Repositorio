<div id="vender" class="col-md-12">
 <button id="cancelarcompra" class="btn btn-danger">Cancelar</button>
  <center><h1>Facturando ventas</h1></center>
  <br><br>
  
   <h3><strong>Cedula del cliente:</strong> <?php
    foreach($clientes as $client){ echo $client->cedula_c;  }  ?> </h3>
   <h3><strong>Nombre del cliente:</strong> <?php
    foreach($clientes as $client){ echo $client->nombre_c;  }  ?> </h3>
   <h3><strong>Telefono del cliente:</strong> <?php
    foreach($clientes as $client){ echo $client->telefono_c;  }  ?> </h3>
   
   
   
   <div class="col-md-1"></div>
   <div class="col-md-10">
      <br><br><br>       
       <div class="form-group">
           <div class="col-md-12">
               <input type="text" class="form-control" placeholder="Numero del producto">
           </div>           
       </div>
       
   </div>
    
    
    
    
    
    
    
</div>




<script>
	
    $(document).ready(function(){ 
     
        
        
        
           $("#cancelarcompra").click(function(){
            
             $("#vender").hide();
            $("#contenconsulcliente").fadeIn();
               $("#cedula").val("");  
            
            
        });  });



</script>