
        <?php
        foreach ($clientes as $c) {

            echo   '<tr>
                <td class="txt_ced">'.$c->cedula_c.'</td>
                <td class="txt_nom">'.$c->nombre_c.'</td>
                <td class="txt_tel">'.$c->telefono_c.'</td>
                <td>
                    <button class="btn btn-default boton" data-toggle="modal" data-target="#myModal2"><img src="'.base_url().'css/img/editar.png"></button>
                    <button onclick="eliminar('.$c->cedula_c.')" class="btn btn-danger"><img src="'.base_url().'css/img/eliminar.png"></button>

                </td>
                
            </tr>';
        }
        ?>








   <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );</script>
          
            
       <script type="text/javascript">
            
            function eliminar(cedula){
                parametros = { "cedula":cedula};
            $.ajax({
            url:"<?php echo base_url(); ?>clientes/eliminarcli",
            type:"post",
            data:parametros,
            success:function(data){
         cargardatos();                 
            },

        }); 





            }




        </script>


        <script type="text/javascript">
        $(document).ready(function() {
   

        $(".boton").click(function() {

    

        var cedula="";
        var nombre="";
        var telefono="";

        $(this).parents("tr").find(".txt_ced").each(function() {
          cedula += $(this).html();
        });
        $(this).parents("tr").find(".txt_nom").each(function() {
          nombre += $(this).html();
        });
        $(this).parents("tr").find(".txt_tel").each(function() {
          telefono += $(this).html();
        });

        $("#ced1").val(cedula);
        $("#nom1").val(nombre);
        $("#tel1").val(telefono);





      });
    });
        </script>









