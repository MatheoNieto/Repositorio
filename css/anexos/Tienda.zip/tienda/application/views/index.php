<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html >
    <head>
        <meta charset="UTF-8">
        <link rel="shortcut icon" type="image/x-icon" href= "<?php echo base_url(); ?>css/images/favicon.ico" />
        <title>Bienvenidos la tienda de Abarrotes</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>css/style.css">
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    </head>
    <body>
        

    <div class="container">
        <div class="card card-container">
            <img id="profile-img" class="profile-img-card" src="<?php echo base_url();?>css/img/tienda.png" />
            <p id="profile-name" class="profile-name-card"></p>
            
                <span id="reauth-email" class="reauth-email"></span>
                <input type="email" id="cedula" class="form-control" placeholder="Ingrese su Cedula" required autofocus>
                <br>
                <input type="password" id="password" class="form-control" placeholder="Password" required>
                <br>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="button" id="btnlogin">Ingresar</button>
           
        </div>
    </div>
    <script>
$(document).ready(function(){ 

    $("#btnlogin").click(function(){

        var cedula = $("#cedula").val();
        var password =$("#password").val();


        var parametros = { "cedula":cedula, "password":password};

        $.ajax({
            url:"<?php echo base_url(); ?>login/ingresar",
            type:"post",
            data:parametros,
            success :function(data){
                if (data == 'false'){
                    alert("Codigo o contrasena incorrecta");
                    $("#contrasena").val("");
                }else{
                    location.reload();
                }

            },

        });      

    });

});
        
        
        
        </script>
    </body>
</html>

