<!DOCTYPE html>
<html>
<head>
	<title>Ventas</title>
	  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<body>
 
 <br><br><br>
 <div class="col-md-1"></div>
<div id="contenconsulcliente" class="col-md-10">
<div class="panel-body panel panel-default">
	<section>
	<h2><p class="text-center"><strong>TIENDA DE ABARROTES</strong></p>
		<p class="text-center"><strong>Ventas</strong></p></h2>
		 <br>
		 <button onclick="location.href='<?php echo base_url();?>login/cerrarsession'" class="btn btn-danger">Cerrar session</button>
		<div class="clearfix"> </div>
		<hr>
		<div class="form-group w3l agileinfo wthree w3-agileits w3layouts w3l">
		
				
				<label for="producto" class="control-label">Cedula del cliente</label>
				<input id="cedula" name="cedula" type="text" class="form-control input-sm" data-error="Ingrese la cédula" required>
		<div id="toolbar" class="form-group">
		<div id="noregist" class="col-md-12">
		<h6 style="color:red;">El cliente no existe click en el boton para registrarlo</h6><button class="btn btn-info" data-toggle="modal" data-target="#myModal">Registrar</button></div>
		
			<button id="btnconsultacliente" class="btn btn-lg"><i class="fa fa-plus-square"></i>Consultar</button>

		</div>
      
      <br>				
					
        </div>
        </section>
        </div>
        </div>
        
         <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Registrando un nuevo cliente</h4>
        </div>
        <div class="modal-body">
        <div class="form-group">
            <div class="col-md-4">
                <input type="text" class="form-control" id="txtcedula" placeholder="cedula" name="cedula">
            </div><div class="col-md-4">
                <input type="text" class="form-control" id="nom" placeholder="Nombre" name="nom">
            </div><div class="col-md-4">
                <input type="text" class="form-control" id="tel" placeholder="Telefono" name="tel">
            </div>
    
        </div>
        <br><br>
        </div>
        <div class="modal-footer">
          <button id="cerrarmodal" type="button" class="btn btn-default" data-dismiss="modal">cerrar</button>
          <button id="regis" type="button" class="btn btn-success" data-dismiss="modal">registrar</button>
        </div>
      </div>
      
    </div>
  </div>
	