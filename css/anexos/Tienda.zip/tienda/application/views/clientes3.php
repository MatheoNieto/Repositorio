
 </tbody>
        <tfoot>
            <tr>
                <th>CÉDULA</th>
                <th>NOMBRE</th>
                <th>TELÉFONO</th>
                <th>ACCIONES</th>
                
            </tr>
        </tfoot>
    </table>







       		
        </div>
        <div class="modal-footer">
          <button id="cerrarmodal" type="button" class="btn btn-default" data-dismiss="modal">cerrar</button>
          
        </div>
      </div>
      
    </div>
  </div>



<!-- Modal -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
            <label for="cedula" class="control-label">Cédula</label>
                <input id="ced1"  type="text" class="form-control input-sm" readonly>
                <div class="help-block with-errors"></div>

                <label for="nombre" class="control-label">Nombres</label>
                <input id="nom1"  type="text" class="form-control input-sm">
                <div class="help-block with-errors"></div>


                <label for="telefono" class="control-label">Telefono </label>
                <input id="tel1"  type="text" class="form-control input-sm">
                <div class="help-block with-errors"></div>
        </div>
        <div class="modal-footer">
            <button onclick="actu();" type="button" class="btn btn-success" data-dismiss="modal">Modificar</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>






		<script type="text/javascript">
			 $(document).ready(function(){ 

            $("#regis").click(function(){

        var cedula = $("#txtcedula").val();     
        var nombre = $("#nom").val();     
        var telefono = $("#tel").val();     


        var parametros = { "cedula":cedula,"nombre":nombre,"telefono":telefono};

        $.ajax({
            url:"<?php echo base_url(); ?>clientes/registrarc",
            type:"post",
            data:parametros,
            complete :function(data){
				$("#txtcedula").val("");  
				$("#nom").val(""); 
				$("#tel").val(""); 
				alert("se registro el cliente");    
            },

        });      

    });
    });

     



		</script>
        <script type="text/javascript">
            

            function cargardatos(){
        $.ajax({
            url:"<?php echo base_url(); ?>clientes/clientesm",
            type:"post",
            success:function(data){
            $("#contentable").html(data);
                   
            },

        }); 
}
        </script>

        


        <script type="text/javascript">
            
function actu(){

        var cedula = $("#ced1").val();     
        var nombre = $("#nom1").val();     
        var telefono = $("#tel1").val();     


        var parametros = { "cedula":cedula,"nombre":nombre,"telefono":telefono};

        $.ajax({
            url:"<?php echo base_url(); ?>clientes/modificar",
            type:"post",
            data:parametros,
            complete :function(data){ 
                  cargardatos();    
                alert("se modificó el cliente");
              
            },

        });      

    }


            


            
        </script>
</body>
</html>