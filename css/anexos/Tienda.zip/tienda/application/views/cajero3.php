	<script>
    $(document).ready(function(){ 
        $("#noregist").hide();
        $("#vender").hide();
        
        
        
           $("#cerrarmodal").click(function(){
            
               $("#noregist").hide();
            
            
        });

    $("#btnconsultacliente").click(function(){

        var cedula = $("#cedula").val();     


        var parametros = { "cedula":cedula};

        $.ajax({
            url:"<?php echo base_url(); ?>cajero/consultar",
            type:"post",
            data:parametros,
            success :function(data){
                
                if (data == 'false'){
                    $("#noregist").fadeIn();
                    
                }else{
                   $("#contenconsulcliente").hide();
                   $("#vender").fadeIn();
                   $("#vender").html(data);
                }
             

            },

        });      

    });
       
        
        
            $("#regis").click(function(){

        var cedula = $("#txtcedula").val();     
        var nombre = $("#nom").val();     
        var telefono = $("#tel").val();     


        var parametros = { "cedula":cedula,"nombre":nombre,"telefono":telefono};

        $.ajax({
            url:"<?php echo base_url(); ?>cajero/registrarc",
            type:"post",
            data:parametros,
            complete :function(data){
                
              $("#noregist").hide();

            },

        });      

    });
        
        
     

});
        
        
    
    
    
    
    
    </script>
		
</body>
</html>