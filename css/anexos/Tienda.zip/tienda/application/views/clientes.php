<!DOCTYPE html>
<html>
<head>
	<title></title>
	  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
			 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">


	
</head>
<body>
	<div class="page-container">	

<div class="col-md-1">
<div class="list-group">
   
  
</div>
 </div>
          
 
 
<div class="col-md-10">
<div class="panel-body panel panel-default">
	<section>
	<h2>
		 <p class="text-center"><b>TIENDA DE ABARROTES</p>
		<P class="text-center"><b>Clientes</p></H2>
		
		<div class="clearfix"> </div>
		<hr>
		<div class="form-group w3l agileinfo wthree w3-agileits w3layouts w3l">
		<form id="formularioC" name="formularioC" method="post" action="agregarusuario">
				
				<label for="cedula" class="control-label">Cédula</label>
				<input id="txtcedula" name="cedula" type="text" class="form-control input-sm" data-error="Ingrese la cédula" required>
				<div class="help-block with-errors"></div>

				<label for="nombre" class="control-label">Nombres</label>
				<input id="nom" name="nom" type="text" class="form-control input-sm" data-error="Ingrese un nombre" required>
				<div class="help-block with-errors"></div>


				<label for="telefono" class="control-label">Telefono </label>
				<input id="tel" name="tel" type="text" class="form-control input-sm" data-error="Ingrese un número de teléfono" required>
				<div class="help-block with-errors"></div>
				<br>
				<div class="help-block with-errors"></div>
				
		
      </select>
      <br>
				
				</form>	
			</div>
		
		<div id="toolbar" class="form-group">
			<button id="regis" type="button" class="btn btn-success">REGISTRAR</button>
			<button onclick="cargardatos();" type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">MOSTRAR CLIENTES</button>
			
		</div>

		         <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">clientes</h4>
        </div>
        <div  class="modal-body">


<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>CÉDULA</th>
                <th>NOMBRE</th>
                <th>TELÉFONO</th>
                <th>ACCIONES</th>
                
            </tr>
        </thead>
        <tbody id="contentable">


