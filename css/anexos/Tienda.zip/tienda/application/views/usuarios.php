<!DOCTYPE html>
<html>
<head>
	<title></title>
	  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	
</head>
<body>
	<div class="page-container">	

<div class="col-md-1">
<div class="list-group">
   
  
</div>
 </div>
          
 
 
<div class="col-md-10">
<div class="panel-body panel panel-default">
	<section>
	<h2>
		 <p class="text-center"><b>TIENDA DE ABARROTES</p>
		<P class="text-center"><b>Usuarios</p></H2>
		<div class="clearfix"> </div>
		<hr>
		<div class="form-group w3l agileinfo wthree w3-agileits w3layouts w3l">
		<form id="formularioC" name="formularioC" method="post" action="agregarusuario">
				
				<label for="cedula" class="control-label">Cédula</label>
				<input id="cedula" name="cedula" type="text" class="form-control input-sm" data-error="Ingrese la cédula" required>
				<div class="help-block with-errors"></div>

				<label for="nombre" class="control-label">Nombres</label>
				<input id="nombres" name="nombres" type="text" class="form-control input-sm" data-error="Ingrese un nombre" required>
				<div class="help-block with-errors"></div>

				<label for="password" class="control-label">Password</label>
				<input id="password" name="nombres" type="password" class="form-control input-sm" data-error="Password" required>
				<div class="help-block with-errors"></div

				<label for="telefono" class="control-label">Telefono </label>
				<input id="telefono" name="telefono" type="text" class="form-control input-sm" data-error="Ingrese un número de teléfono" required>
				<div class="help-block with-errors"></div>

				<br>
				<label for="rol" class="control-label">ROL </label>
				<select name="rol" id="rol">
					<option value="1">Aministrador</option>
					<option value="2">Cajero</option>
				</select>

				<div class="help-block with-errors"></div>
				
		
      </select>
      <br>
				
				</form>	
			</div>
		
		<div id="toolbar" class="form-group">
			<button type="submit" class="btn btn-lg"><i class="fa fa-plus-square"></i> GUARDAR</button>
			<button type="submit" class="btn btn-lg"><i class="fa fa-pencil-square"></i> MODIFICAR</button>
			<button type="submit" class="btn btn-lg"><i class="fa fa-trash"></i> ELIMINAR</button>
		</div>
</body>
</html>