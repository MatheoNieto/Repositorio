<!DOCTYPE html>
<html>
<head>
	<title></title>
	  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	
</head>
<body>
	<div class="page-container">	

<div class="col-md-1">
<div class="list-group">
   
  
</div>
 </div>
          
 
 
<div class="col-md-10">
<div class="panel-body panel panel-default">
	<section>
	<h2>
		 <p class="text-center"><b>TIENDA DE ABARROTES</p>
		<P class="text-center"><b>Productos</p></H2>
		<div class="clearfix"> </div>
		<hr>
		<div class="form-group w3l agileinfo wthree w3-agileits w3layouts w3l">
		<form id="formularioC" name="formularioC" method="post" action="agregarusuario">
				

				<label for="nombre" class="control-label">Nombre Producto</label>
				<input id="nombres" name="nombres" type="text" class="form-control input-sm" data-error="Ingrese un nombre" required>
				<div class="help-block with-errors"></div>

				<label for="nombre" class="control-label">Descrición Producto</label>
				<input id="descripcion" name="descripcion" type="text" class="form-control input-sm" data-error="Ingrese una Descripcion" required>
				<div class="help-block with-errors"></div>

				<label for="nombre" class="control-label">Cantidad Producto</label>
				<input id="cantidad" name="cantidad" type="text" class="form-control input-sm" data-error="Ingrese una Cantidad" required>
				<div class="help-block with-errors"></div>

				<label for="nombre" class="control-label">Precio Producto</label>
				<input id="precio" name="precio" type="text" class="form-control input-sm" data-error="Ingrese un Precio" required>
				<div class="help-block with-errors"></div>

				

				<div class="help-block with-errors"></div>
				<br>
				<div class="help-block with-errors"></div>
				
		
      </select>
      <br>
				
				</form>	
			</div>
		
		<div id="toolbar" class="form-group">
			<button type="submit" class="btn btn-lg"><i class="fa fa-plus-square"></i> GUARDAR</button>
			<button type="submit" class="btn btn-lg"><i class="fa fa-pencil-square"></i> MODIFICAR</button>
			<button type="submit" class="btn btn-lg"><i class="fa fa-trash"></i> ELIMINAR</button>
			<button type="submit" class="btn btn-lg"><i class="fa fa-pencil-square"></i> ABASTECER</button>
		</div>
</body>
</html>