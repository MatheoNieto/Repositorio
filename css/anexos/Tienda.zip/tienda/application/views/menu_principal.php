<!DOCTYPE html>
<html>
<head>
	<title>Menu Principal</title>
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style type="text/css">
	.hero-widget { text-align: center; padding-top: 20px; padding-bottom: 20px; }
.hero-widget .icon { display: block; font-size: 96px; line-height: 96px; margin-bottom: 10px; text-align: center; }
.hero-widget var { display: block; height: 64px; font-size: 64px; line-height: 64px; font-style: normal; }
.hero-widget label { font-size: 17px; }
.hero-widget .options { margin-top: 10px; }
</style>
</head>
<body>

<br />

<div class="container">
	<div class="row">
		<div class="col-sm-2">
    	    <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="glyphicon glyphicon-user"></i>
                </div>
                <div class="text">
                    <label class="text-muted">Clientes</label>
                </div>
                <div class="options">
                    <a href="javascript:;" class="btn btn-primary btn-lg" onclick="location.href='<?php echo base_url();?>clientes'"> Clientes</a>
                </div>
            </div>
		</div>
        <div class="col-sm-2">
            <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="glyphicon glyphicon-user"></i>
                </div>
                <div class="text">
                    <label class="text-muted">Usuarios</label>
                </div>
                <div class="options">
                    <a href="javascript:;" class="btn btn-primary btn-lg" onclick="location.href='<?php echo base_url();?>usuarios'"> Usuarios</a>
                </div>
            </div>
		</div>
        <div class="col-sm-2">
            <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="glyphicon glyphicon-shopping-cart"></i>
                </div>
                <div class="text">
                    <label class="text-muted">Productos</label>
                </div>
                <div class="options">
                    <a href="javascript:;" class="btn btn-primary btn-lg" onclick="location.href='<?php echo base_url();?>productos'"> Productos</a>
                </div>
            </div>
    	</div>
        <div class="col-sm-2">
            <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="glyphicon glyphicon-barcode"></i>
                </div>
                <div class="text">
                    <label class="text-muted">Ventas</label>
                </div>
                <div class="options">
                    <a href="javascript:;" class="btn btn-primary btn-lg"> Ventas</a>
                </div>
            </div>
            <br>
        </div>
            <div class="col-sm-2">
            <div class="hero-widget well well-sm">
                <div class="icon">
                     <i class="glyphicon glyphicon-remove"></i>
                </div>
                <div class="text">
                    <label class="text-muted">Cerrar Sessión</label>
                </div>
                <div class="options">
                    <a href="javascript:;" class="btn btn-primary btn-lg" onclick="location.href='<?php echo base_url();?>login/cerrarsession'"> Cerrar Sessión</a>
                </div>
            </div>
		</div>
		
	</div>
</div>

</body>
</html>
