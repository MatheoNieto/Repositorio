<?php

class Clientes_model extends CI_Model {
    public function __construct(){
        parent::__construct();
    }
    
    
    public function regiscliente($datos){
        $this->db->insert('clientes',$datos); 
        
        
        
    }

    public function clientesm(){

   $this->db->select('*');
   $resultado = $this->db->get('clientes'); 
   return $resultado->result();
    }

    public function eliminar($codigo){

      $this->db->where('cedula_c',$codigo);
      $this->db->delete('clientes');


    }

    public function modificarcli($datos,$cedula){
      $this->db->set($datos);
      $this->db->where('cedula_c',$cedula);
      $this->db->update('clientes');
    }
        
    }