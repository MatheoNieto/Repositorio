<?php

class Cajero_model extends CI_Model {
    public function __construct(){
        parent::__construct();
    }
    
    
        public function cliente($codigo){
       
       $this->db->where('cedula_c',$codigo);
       $resultado= $this->db->get('clientes');     
       
       if($resultado->num_rows()>0){
           return $resultado->result();
       }else{
           return false;
        
       }  
        
    }
    
    
    
    public function regiscliente($datos){
        $this->db->insert('clientes',$datos); 
        
        
        
    }

        
    }